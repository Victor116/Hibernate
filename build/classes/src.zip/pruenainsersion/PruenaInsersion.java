package pruenainsersion;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/** @author VICTOR  */
public class PruenaInsersion {

    private static SessionFactory factory;
    private static ServiceRegistry serviceRegistry;
    
    /** @param args the command line arguments */
    public static void main(String[] args) {
        System.err.println("Iniciando" );
        try{
            Configuration configuration = new Configuration();
            System.err.println("Leyendo configuracion." );
            configuration.configure();
            serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();        
            factory = configuration.buildSessionFactory(serviceRegistry);
            System.err.println("Conexion estrablecida." );
        }catch (Throwable ex) { 
           System.err.println("No se puede crear la Sesion" + ex);
           throw new ExceptionInInitializerError(ex); 
        }
        
        //addAlumnoConCiudad();
    }
    
    /* Crea nuevos alumnos */
    public static void addAlumnoWitdAddress(){        
        Session session = factory.openSession();
        Transaction tx = null;
        Integer daoID = null;
        try{
            tx = session.beginTransaction();
            Address address = new Address("OMR Road", "Chennai", "TN", "600097");
            Student student1 = new Student("Eswar", address);
            Student student2 = new Student("Joe", address);
            session.save(student1);
            session.save(student2);
            tx.commit();
        }catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        }finally {
           session.close(); 
        }
    }
    
    /* Crea nuevos alumnos */
    public static void addAlumnoConCiudad(){        
        Session session = factory.openSession();
        Transaction tx = null;
        Integer daoID = null;
        try{
            tx = session.beginTransaction();
            Ciudad ciudad = new Ciudad("Tuxtla");
            Ciudad ciudad1 = new Ciudad("Coatza");
            
            Alumno alumno1 = new Alumno("Pepe", "M", 18, ciudad);
            Alumno alumno2 = new Alumno("Luis", "M", 20, ciudad1);
            Alumno alumno3 = new Alumno("Mary", "F", 25, ciudad1);
            Alumno alumno4 = new Alumno("Isabel", "F", 60, ciudad1);
            Alumno alumno5 = new Alumno("Juan", "M", 5, ciudad1);
            
            session.save(alumno1);
            session.save(alumno2);
            session.save(alumno3);
            session.save(alumno4);
            session.save(alumno5);
            
            tx.commit();
        }catch (HibernateException e) {
           if (tx!=null) tx.rollback();
           e.printStackTrace(); 
        }finally {
           session.close(); 
        }
    }
}
